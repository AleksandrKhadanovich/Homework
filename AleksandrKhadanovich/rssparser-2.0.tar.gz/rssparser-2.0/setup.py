from setuptools import setup, find_packages
from os.path import join, dirname



setup(
    name="rssparser",
    packages=find_packages(),
    version='2.0',
    author = "Aleksandr Khadanovich",
    author_email = "aleksan20@yahoo.com",
    description = "RSS Reader",
    
    long_description=open(join(dirname(__file__), 'README.txt')).read(),
    entry_points={
        'console_scripts':
            ['rss_reader = rssparser.rss_reader:parse_news']
        },
    install_requires=[
        "lxml == 4.6.3",
        "bs4 == 0.0.1",
        "requests == 2.26.0"
    ],                                       
    test_suite='testFT',   
)
