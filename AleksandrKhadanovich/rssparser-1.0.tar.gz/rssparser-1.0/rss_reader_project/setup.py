from setuptools import setup, find_packages
from os.path import join, dirname

with open('C:\\Users\\User\\rss_reader_project\\README.md') as file:
    read_me_description = file.read()


setup(
    name="rssparser",
    packages=find_packages(),
    package_dir = {'rssparser': 'rss_reader_project'},
    version='1.0',
    author = "Aleksandr Khadanovich",
    author_email = "aleksan20@yahoo.com",
    description = "RSS Reader",
    long_description=read_me_description,
    #py_modules=['rssparser','rss_reader_project'],
    entry_points={
        'console_scripts':
            ['rss_reader = rss_reader_project.rssparser.rss_reader:parse_news']
        },
    install_requires=[
        "lxml == 4.6.3",
        "bs4 == 0.0.1",
        "requests == 2.26.0"
    ],                                       
    test_suite='TestFT',   
)
