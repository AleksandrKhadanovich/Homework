# rss_reader.py

rss_reader is a Python command-line utility to print information in human-readable format from RSS URL given.

## Requirements

To use rss_reader lxml, bs4,requests libraries should be installed.
rss_reader.py is on PYTHONPATH.

## Usage

###To run rss-reader you should enter:
>python rss_reader.py "URL" or rss_reader "URL",
where URL is valid RSS URL.

###rss_reader provides optional arguments:
--Limit, --version, --json, --help.

###JSON format is representation of data as a list of objects consisting of name - value pairs.
rss_reader lets prints result as JSON in stdout.
if --json argument rss_reader represent data as follows:
[
    {
        "Title": "text", 
        "Link": "text", 
        "Published": "text"
    }, 
    {
        "Title": "text", 
        "Link": "text", 
        "Published": "text"
    }, 
    {
        "Title": "text", 
        "Link": "text", 
        "Published": "text"
    }
] 

For more information enter 
>python rss_reader.py --help 
in command line.

## License
Freeware license



output file encourding = "utf-8"

MS Windows
For MS Windows, recent lxml releases feature community donated binary distributions, although you might still want to take a look at the related FAQ entry. If you fail to build lxml on your MS Windows system from the signed and tested sources that we release, consider using the binary builds from PyPI or the unofficial Windows binaries that Christoph Gohlke generously provides.

Linux
On Linux (and most other well-behaved operating systems), pip will manage to build the source distribution as long as libxml2 and libxslt are properly installed, including development packages, i.e. header files, etc. See the requirements section above and use your system package management tool to look for packages like libxml2-dev or libxslt-devel. If the build fails, make sure they are installed.

Alternatively, setting STATIC_DEPS=true will download and build both libraries automatically in their latest version, e.g. STATIC_DEPS=true pip install lxml.

MacOS-X
On MacOS-X, use the following to build the source distribution, and make sure you have a working Internet connection, as this will download libxml2 and libxslt in order to build them:

STATIC_DEPS=true sudo pip install lxml
